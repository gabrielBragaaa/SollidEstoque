package Estoque;

import Estoque.entities.Usuario;
import Estoque.repositories.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class UsuarioInit implements CommandLineRunner {

    private final UsuarioRepository usuarioRepository;

    public UsuarioInit(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    //Senha criptografada
    @Override
    public void run(String... args) throws Exception {
        if (usuarioRepository.findByUsername("tome.mendes").isEmpty()) {
            String senhaCriptografada = new BCryptPasswordEncoder().encode("teste");

            Usuario user = new Usuario();
            user.setUsername("tome.mendes");
            user.setPassword(senhaCriptografada);
            user.setRole("GUEST");

            usuarioRepository.save(user);

            System.out.println("Usuário criado com sucesso.");
        } else {
            System.out.println("Usuário já existe.");
        }
    }
}
